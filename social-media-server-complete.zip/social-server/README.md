# خادم تطبيق التواصل الاجتماعي

هذا المشروع هو خادم API كامل مبني باستخدام **Node.js وExpress.js**، ومتكامل مع **Supabase Auth وPostgreSQL وStorage**. يوفر الخادم عمليات الملف الشخصي، المنشورات، الإعجابات، التعليقات، والإشعارات.

## 1. المتطلبات

يحتاج التشغيل إلى Node.js إصدار 20 أو أحدث، وحساب Supabase. لا يحتاج المشروع إلى Docker.

## 2. إعداد Supabase

1. افتح مشروعًا في Supabase.
2. انتقل إلى **SQL Editor** والصق محتوى `supabase/schema.sql` ثم نفذه.
3. من إعدادات API انسخ `Project URL` و`service_role key`.
4. لا تشارك `service_role key` ولا تضعه داخل تطبيق الهاتف.
5. أنشئ Storage Bucket باسم `post-images`. إذا كانت الصور خاصة، استخدم روابط موقعة بدل الروابط العامة.

## 3. التشغيل المحلي

```bash
cp .env.example .env
# افتح .env وضع بيانات Supabase
npm install
npm run dev
```

يعمل الخادم افتراضيًا على `http://localhost:3000`. اختبره من خلال:

```bash
curl http://localhost:3000/health
```

## 4. تسجيل الدخول

التسجيل وتسجيل الدخول يتمان من تطبيق الهاتف باستخدام Supabase Auth. بعد تسجيل الدخول، أرسل Access Token في كل طلب:

```http
Authorization: Bearer SUPABASE_ACCESS_TOKEN
```

عند إنشاء المستخدم في Supabase Auth، ينشئ trigger ملفًا تلقائيًا في جدول `public.users`.

## 5. أهم المسارات

| الطريقة | المسار | الوظيفة |
|---|---|---|
| GET | `/health` | فحص الخادم |
| GET | `/api/me` | جلب ملف المستخدم |
| PUT | `/api/me` | تحديث الملف الشخصي |
| POST | `/api/me/device-token` | حفظ رمز الجهاز للإشعارات |
| GET | `/api/me/notifications` | جلب الإشعارات |
| PATCH | `/api/me/notifications/:id/read` | تعليم إشعار كمقروء |
| GET | `/api/posts?limit=10&cursor=` | جلب التغذية مع pagination |
| POST | `/api/posts` | إنشاء منشور |
| DELETE | `/api/posts/:id` | حذف منشور يملكه المستخدم |
| POST | `/api/posts/:id/like` | إضافة/إزالة إعجاب |
| GET | `/api/posts/:id/comments` | جلب التعليقات |
| POST | `/api/posts/:id/comments` | إضافة تعليق |

## 6. أمثلة الطلبات

إنشاء منشور:

```bash
curl -X POST http://localhost:3000/api/posts \\
  -H "Authorization: Bearer TOKEN" \\
  -H "Content-Type: application/json" \\
  -d '{"content":"أول منشور لي","image_url":null}'
```

إضافة تعليق:

```bash
curl -X POST http://localhost:3000/api/posts/POST_ID/comments \\
  -H "Authorization: Bearer TOKEN" \\
  -H "Content-Type: application/json" \\
  -d '{"content":"تعليق تجريبي"}'
```

## 7. النشر على Render

أنشئ **Web Service** جديدًا واربطه بمستودع GitHub، ثم استخدم:

- Build Command: `npm install`
- Start Command: `npm start`
- Environment: `Node`

أضف متغيرات `.env` في إعدادات Render، خصوصًا `SUPABASE_URL` و`SUPABASE_SERVICE_ROLE_KEY` و`NODE_ENV=production` و`CORS_ORIGIN`. بعد النشر استخدم عنوان Render في تطبيق الهاتف مثل:

```text
EXPO_PUBLIC_API_URL=https://your-service.onrender.com/api
```

## 8. ملاحظات أمنية

الخادم يطبق Helmet وCORS وRate Limiting والتحقق من المدخلات باستخدام Zod. لا تضع أي مفتاح خدمة في GitHub أو في تطبيق الهاتف. في الإنتاج، حدّد `CORS_ORIGIN` على نطاق تطبيقك بدل استخدام `*`، وفعّل مراقبة الأخطاء والنسخ الاحتياطي في Supabase.

## 9. ما يحتاجه تطبيق الهاتف

بعد تسجيل الدخول من Supabase، خزّن access token وأرسله مع الطلبات. استخدم `POST /api/me/device-token` لتسجيل رمز FCM. لرفع صورة، ارفعها من الهاتف إلى Supabase Storage باستخدام مفتاح anon العام، ثم أرسل رابط الصورة في `image_url` عند إنشاء المنشور.
