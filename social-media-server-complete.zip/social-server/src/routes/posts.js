import { Router } from 'express';
import { z } from 'zod';
import { supabase } from '../config/supabase.js';
import { asyncHandler } from '../middleware/errors.js';

const router = Router();
const postSchema = z.object({ content: z.string().trim().max(5000).default(''), image_url: z.string().url().nullable().optional() }).refine(v => v.content.length > 0 || v.image_url, { message: 'المنشور يحتاج إلى نص أو صورة' });
const commentSchema = z.object({ content: z.string().trim().min(1).max(1000) });

router.get('/', asyncHandler(async (req, res) => {
  const limit = Math.min(Math.max(Number(req.query.limit) || 10, 1), 50);
  const cursor = req.query.cursor;
  let query = supabase.from('posts').select('*, users!user_id(id,full_name,username,avatar_url), likes(user_id), comments(count)').order('created_at', { ascending: false }).limit(limit);
  if (cursor) query = query.lt('created_at', cursor);
  const { data, error } = await query;
  if (error) throw error;
  const posts = (data || []).map(p => ({ ...p, likesCount: p.likes?.length || 0, commentsCount: p.comments?.[0]?.count || 0, isLikedByMe: (p.likes || []).some(l => l.user_id === req.user.id), likes: undefined, comments: undefined }));
  res.json({ posts, nextCursor: posts.length === limit ? posts.at(-1)?.created_at : null, hasMore: posts.length === limit });
}));

router.post('/', asyncHandler(async (req, res) => {
  const input = postSchema.parse(req.body);
  const { data, error } = await supabase.from('posts').insert({ user_id: req.user.id, content: input.content, image_url: input.image_url || null }).select('*, users!user_id(id,full_name,username,avatar_url)').single();
  if (error) { const e = new Error(error.message); e.statusCode = 400; throw e; }
  res.status(201).json({ post: data });
}));

router.delete('/:id', asyncHandler(async (req, res) => {
  const { error } = await supabase.from('posts').delete().eq('id', req.params.id).eq('user_id', req.user.id);
  if (error) throw error;
  res.status(204).send();
}));

router.post('/:id/like', asyncHandler(async (req, res) => {
  const { data: existing, error: findError } = await supabase.from('likes').select('id').eq('post_id', req.params.id).eq('user_id', req.user.id).maybeSingle();
  if (findError) throw findError;
  if (existing) { const { error } = await supabase.from('likes').delete().eq('id', existing.id); if (error) throw error; return res.json({ liked: false }); }
  const { error } = await supabase.from('likes').insert({ post_id: req.params.id, user_id: req.user.id });
  if (error) { const e = new Error(error.message); e.statusCode = 400; throw e; }
  res.json({ liked: true });
}));

router.get('/:id/comments', asyncHandler(async (req, res) => {
  const { data, error } = await supabase.from('comments').select('*, users!user_id(id,full_name,username,avatar_url)').eq('post_id', req.params.id).order('created_at', { ascending: true });
  if (error) throw error;
  res.json({ comments: data });
}));

router.post('/:id/comments', asyncHandler(async (req, res) => {
  const input = commentSchema.parse(req.body);
  const { data, error } = await supabase.from('comments').insert({ post_id: req.params.id, user_id: req.user.id, content: input.content }).select('*, users!user_id(id,full_name,username,avatar_url)').single();
  if (error) { const e = new Error(error.message); e.statusCode = 400; throw e; }
  res.status(201).json({ comment: data });
}));
export default router;
