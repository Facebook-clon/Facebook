import { supabase } from '../config/supabase.js';

export async function requireAuth(req, res, next) {
  try {
    const header = req.headers.authorization || '';
    const token = header.startsWith('Bearer ') ? header.slice(7) : null;
    if (!token) return res.status(401).json({ error: 'UNAUTHORIZED', message: 'يلزم تسجيل الدخول' });

    const { data, error } = await supabase.auth.getUser(token);
    if (error || !data.user) return res.status(401).json({ error: 'INVALID_TOKEN', message: 'رمز الدخول غير صالح' });
    req.user = data.user;
    next();
  } catch (error) { next(error); }
}
