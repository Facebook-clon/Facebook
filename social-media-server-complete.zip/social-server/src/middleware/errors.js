export function notFound(req, res) {
  res.status(404).json({ error: 'NOT_FOUND', message: 'المسار غير موجود' });
}

export function errorHandler(err, req, res, next) {
  console.error(err);
  const status = err.statusCode || 500;
  res.status(status).json({
    error: err.code || 'SERVER_ERROR',
    message: status === 500 ? 'حدث خطأ داخلي في الخادم' : err.message
  });
}

export function asyncHandler(fn) {
  return (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
}
