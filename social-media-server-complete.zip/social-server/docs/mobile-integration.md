# ربط تطبيق Expo بالخادم

في ملف البيئة الخاص بتطبيق Expo:

```env
EXPO_PUBLIC_API_URL=https://your-service.onrender.com/api
EXPO_PUBLIC_SUPABASE_URL=https://YOUR_PROJECT.supabase.co
EXPO_PUBLIC_SUPABASE_ANON_KEY=YOUR_ANON_KEY
```

يجب إرسال Access Token الناتج من Supabase Auth في رأس كل طلب:

```js
const { data: { session } } = await supabase.auth.getSession();
await api.get('/posts', {
  headers: { Authorization: `Bearer ${session.access_token}` }
});
```

لا تستخدم `SUPABASE_SERVICE_ROLE_KEY` في Expo؛ هذا المفتاح مخصص للخادم فقط.
