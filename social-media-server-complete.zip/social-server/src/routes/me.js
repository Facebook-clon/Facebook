import { Router } from 'express';
import { z } from 'zod';
import { supabase } from '../config/supabase.js';
import { asyncHandler } from '../middleware/errors.js';

const router = Router();
const profileSchema = z.object({ full_name: z.string().trim().min(1).max(80), username: z.string().trim().min(3).max(30).regex(/^[a-zA-Z0-9_]+$/), avatar_url: z.string().url().nullable().optional() });

router.get('/', asyncHandler(async (req, res) => {
  const { data, error } = await supabase.from('users').select('*').eq('id', req.user.id).maybeSingle();
  if (error) throw error;
  res.json({ user: data || { id: req.user.id, email: req.user.email } });
}));

router.put('/', asyncHandler(async (req, res) => {
  const input = profileSchema.parse(req.body);
  const { data, error } = await supabase.from('users').upsert({ id: req.user.id, ...input }, { onConflict: 'id' }).select().single();
  if (error) { const e = new Error(error.message); e.statusCode = 400; throw e; }
  res.json({ user: data });
}));

router.post('/device-token', asyncHandler(async (req, res) => {
  const schema = z.object({ token: z.string().min(10).max(4096) });
  const { token } = schema.parse(req.body);
  const { error } = await supabase.from('users').update({ fcm_token: token }).eq('id', req.user.id);
  if (error) throw error;
  res.status(204).send();
}));

router.get('/notifications', asyncHandler(async (req, res) => {
  const { data, error } = await supabase.from('notifications').select('*, sender:users!sender_id(id,full_name,username,avatar_url)').eq('recipient_id', req.user.id).order('created_at', { ascending: false }).limit(50);
  if (error) throw error;
  res.json({ notifications: data });
}));

router.patch('/notifications/:id/read', asyncHandler(async (req, res) => {
  const { data, error } = await supabase.from('notifications').update({ is_read: true }).eq('id', req.params.id).eq('recipient_id', req.user.id).select().single();
  if (error) { const e = new Error('الإشعار غير موجود'); e.statusCode = 404; throw e; }
  res.json({ notification: data });
}));
export default router;
